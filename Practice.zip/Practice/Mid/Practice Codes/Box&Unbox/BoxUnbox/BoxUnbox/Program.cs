﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxUnbox
{
    class Program
    {
        static void Main(string[] args)
        {
            /*int x = 10;
            object o = x; //Boxing
            double y = (double)o; //Unboxing
            Console.WriteLine(x);*/



            /*string a = null;
            object o = a; //Boxing
            int b = (int)o; //Unboxing - InvalidCastException here!
            Console.WriteLine(a);*/

            
            /*Nullable <int> i = null;
            //int? i = null;

            if
                (i.HasValue)
                Console.WriteLine(i.Value);
            else
                Console.WriteLine("Null");*/



            //int? x = null;
             //int  y = x ?? 56464;

            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
