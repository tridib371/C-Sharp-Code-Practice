﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyDemo
{
    
    class Student
    {
        int _id;
        string name;
        float _CGPA;
        
        public int id
        {
            get { return this._id; }
            set { this._id = value; }
        }

        public string Name 
        {

           


        get
            {
                if (this.name != null)
                    return name;
                return "there is no name";
            } 
            set => name = value; 
        }

        public float CGPA {  get => _CGPA; set => _CGPA =3.4f; }
       // public float CGPA { protected get => _CGPA; set => _CGPA = 3.4f; }

        public double Salary { get; set; } = 10000; //Auto-implmented property
    }

    class TestStudent
    {
        static void Main(string[] args)
        {
            Student s = new Student();
            s.Name = "hfhgfhg";
            Console.WriteLine(s.Name);
            s.CGPA = 3.6f;               //setting the value
            Console.WriteLine(s.Salary);    //getting the value
            Console.WriteLine(s.CGPA);

            Console.ReadKey();
            
        }
    }
}
