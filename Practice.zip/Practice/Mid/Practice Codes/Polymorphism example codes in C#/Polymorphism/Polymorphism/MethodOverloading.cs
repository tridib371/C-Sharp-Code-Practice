﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Compile-time Polymorphism
//Method Overloading in C#

namespace Polymorphism
{
    class MethodOverloading
    {
        public void Test()
        {
            Console.WriteLine("Test method with no parameter");
        }
        public void Test(int num)
        {
            Console.WriteLine("Test method with one interger parameter");
        }
        public void Test(string line)
        {
            Console.WriteLine("Test method with one string parameter");
        }
        public void Test(int num, string line)
        {
            Console.WriteLine("Test method with one integer and one string parameter");
        }
        public void Test(string line, int num)
        {
            Console.WriteLine("Test method with one string and one integer parameter");
        }
        static void Main(string[] args)
        {
            MethodOverloading m = new MethodOverloading();
            m.Test();
            m.Test(10);
            m.Test("Hello World");
            m.Test(10, "Hello World");
            m.Test("Hello World", 10);

            string x = "hello world";
            Console.WriteLine(x.Length);
            
            // All these are overloaded method under string class in C#
            //x.IndexOf('o');
           // x.IndexOf('o', 5);
            //x.IndexOf("ll");

            Console.ReadKey();
        }
    }
}
