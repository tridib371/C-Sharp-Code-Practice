﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Run-time Polymorphism
//Method Overriding in C#
// Here child class re-defines the parent class Test method with the permission

namespace Polymorphism
{
    class ParentClass
    {
        public virtual void Test()
        {
            Console.WriteLine("Test from Parent");
        }
    }
    class ChildClass : ParentClass
    {
        public override void Test()
        {
            Console.WriteLine("Test from Child");
        }
    }

    class TestRunMethodOverriding
    {
        static void Main(string[] args)
        {
            ChildClass c = new ChildClass();
            c.Test();

            ParentClass p = new ChildClass();
            p.Test();

            Console.ReadKey();
        }
    }
}
