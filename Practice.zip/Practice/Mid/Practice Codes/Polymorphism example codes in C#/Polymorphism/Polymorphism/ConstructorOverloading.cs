﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// This is an example for Constructor Chaining in C#

namespace Polymorphism
{
    class Person
    {
        public Person() : this(10)
        {
            Console.WriteLine("Person constructor with no parameter");
        }
        public Person(int id) : this("This is a string")
        {
            Console.WriteLine("Person constructor with one id parameter");
        }
        public Person(string name) 
        {
            Console.WriteLine("Person constructor with one string parameter");
        }
    }
    class Teacher : Person
    {
        public Teacher() : this(20)
        {
            Console.WriteLine("Teacher constructor with no parameter");
        } 
        public Teacher(int id) : this("This is a line")
        {
            Console.WriteLine("Teacher constructor with one id parameter");
        }
        public Teacher(string name) : base()
        {
            Console.WriteLine("Teacher constructor with one string parameter");
        }
    }
    class Student : Teacher
    {
        public Student() 
        {
            Console.WriteLine("Student constructor with no parameter");
        }
        public Student(int id) : base("ABC")
        {
            Console.WriteLine("Student constructor with one id parameter");
        }
        public Student(string name)
        {
            Console.WriteLine("Student constructor with one string parameter");
        }
    }
    class ConstructorOverloading
    {
        static void Main(string[] args)
        {
            Student s = new Student(10);


            Console.ReadKey();
        }                
    }
}
