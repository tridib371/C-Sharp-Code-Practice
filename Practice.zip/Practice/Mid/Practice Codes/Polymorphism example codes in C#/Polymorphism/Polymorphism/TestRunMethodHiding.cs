﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Run-time Polymorphism
//Method Hiding in C#
// Here child class re-defines the parent class Test method without the permission
namespace Polymorphism
{
    class Parent
    {
        public void Test()
        {
            Console.WriteLine("Test from Parent");
        }
    }
    class Child : Parent
    {
        public new void Test()
        {
            Console.WriteLine("Test from Child");
        }
    }
    class TestRunMethodHiding
    {
        static void Main(string[] args)
        {
            Child c = new Child();
            c.Test();

            Parent p = new Child();
            p.Test();

            Console.ReadKey();
        }
    }
}
