﻿using System;

class Start
{
    public static void Main(string[] args)
    {
        
        BookShop bookShop = new BookShop("My Book Shop");

        
        StoryBook storyBook1 = new StoryBook("1234567890", "The Adventures", "John Doe", 10.99, 50, "Adventure");
        StoryBook storyBook2 = new StoryBook("2345678901", "Mystery Mansion", "Jane Smith", 12.99, 30, "Mystery");
        StoryBook storyBook3 = new StoryBook("3456789012", "Magic Kingdom", "Alice Johnson", 8.99, 20, "Fantasy");
        StoryBook storyBook4 = new StoryBook("4567890123", "Lost Treasure", "Bob White", 15.99, 15, "Adventure");
        StoryBook storyBook5 = new StoryBook("5678901234", "Dreamland", "Eva Brown", 9.99, 40, "Fantasy");

       
        TextBook textBook1 = new TextBook("6789012345", "Mathematics", "Professor X", 20.99, 25, 8);
        TextBook textBook2 = new TextBook("7890123456", "History of Science", "Dr. Y", 18.99, 35, 10);
        TextBook textBook3 = new TextBook("8901234567", "English Literature", "Professor Z", 22.99, 30, 9);
        TextBook textBook4 = new TextBook("9012345678", "Physics Principles", "Dr. A", 24.99, 20, 11);
        TextBook textBook5 = new TextBook("0123456789", "Chemistry Basics", "Dr. B", 19.99, 28, 10);

        
        bookShop.InsertBook(storyBook1);
        bookShop.InsertBook(storyBook2);
        bookShop.InsertBook(storyBook3);
        bookShop.InsertBook(storyBook4);
        bookShop.InsertBook(storyBook5);
        bookShop.InsertBook(textBook1);
        bookShop.InsertBook(textBook2);
        bookShop.InsertBook(textBook3);
        bookShop.InsertBook(textBook4);
        bookShop.InsertBook(textBook5);

        
        Console.WriteLine("=== Displaying all books ===");
        bookShop.ShowAllBooks();

        Console.WriteLine("\n=== Selling some books ===");
        bookShop.ShowAllBooks();

        Console.ReadKey();
    }
}
