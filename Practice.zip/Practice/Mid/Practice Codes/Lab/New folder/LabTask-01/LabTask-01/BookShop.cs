﻿using System;

public class BookShop
{
    public string Name { get; set; }
    private Book[] books = new Book[100];
    private int bookCount = 0;

    public BookShop() { }

    public BookShop(string name)
    {
        Name = name;
    }

    public void SetName(string name)
    {
        Name = name;
    }

    public string GetName()
    {
        return Name;
    }

    public bool InsertBook(Book b)
    {
        if (bookCount < 100)
        {
            books[bookCount++] = b;
            return true;
        }
        else
        {
            Console.WriteLine("BookShop is full, cannot add more books.");
            return false;
        }
    }

    
    public void ShowAllBooks()
    {
        Console.WriteLine($"Books in {Name}:");
        for (int i = 0; i < bookCount; i++)
        {
            Console.WriteLine($"Book {i + 1}:");
            books[i].ShowDetails();
            Console.WriteLine("-------------------------");
        }
    }

    }

