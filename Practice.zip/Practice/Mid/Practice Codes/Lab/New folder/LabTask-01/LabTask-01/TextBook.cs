﻿using System;

public class TextBook : Book
{
    public int Standard { get; set; }

    public TextBook() { }

    public TextBook(string isbn, string bookTitle, string authorName, double price, int availableQuantity, int standard): base(isbn, bookTitle, authorName, price, availableQuantity)
    {
        Standard = standard;
    }

    public void SetStandard(int standard)
    {
        Standard = standard;
    }

    public int GetStandard()
    {
        return Standard;
    }

    public override void ShowDetails()
    {
        base.ShowDetails();
        Console.WriteLine($"Standard: {Standard}");
    }
}
