﻿using System;

public class StoryBook : Book
{
    public string Category { get; set; }

    public StoryBook() { }

    public StoryBook(string isbn, string bookTitle, string authorName, double price, int availableQuantity, string category): base(isbn, bookTitle, authorName, price, availableQuantity)
    {
        Category = category;
    }

    public void SetCategory(string category)
    {
        Category = category;
    }

    public string GetCategory()
    {
        return Category;
    }

    public override void ShowDetails()
    {
        base.ShowDetails();
        Console.WriteLine($"Category: {Category}");
    }
}
