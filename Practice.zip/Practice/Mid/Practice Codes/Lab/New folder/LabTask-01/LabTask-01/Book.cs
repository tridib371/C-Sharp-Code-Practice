﻿using System;

public class Book
{
    public string Isbn { get; set; }
    public string BookTitle { get; set; }
    public string AuthorName { get; set; }
    public double Price { get; set; }
    public int AvailableQuantity { get; set; }

    public Book() { }

    public Book(string isbn, string bookTitle, string authorName, double price, int availableQuantity)
    {
        this.Isbn = isbn;
        this.BookTitle = bookTitle;
        this.AuthorName = authorName;
        this.Price = price;
        this.AvailableQuantity = availableQuantity;
    }

    public void SetIsbn(string isbn)
    {
        this.Isbn = isbn;
    }

    public void SetBookTitle(string bookTitle)
    {
        this.BookTitle = bookTitle;
    }

    public void SetAuthorName(string authorName)
    {
        AuthorName = authorName;
    }

    public void SetPrice(double price)
    {
        Price = price;
    }

    public void SetAvailableQuantity(int availableQuantity)
    {
        AvailableQuantity = availableQuantity;
    }

    public string GetIsbn()
    {
        return Isbn;
    }

    public string GetBookTitle()
    {
        return BookTitle;
    }

    public string GetAuthorName()
    {
        return AuthorName;
    }

    public double GetPrice()
    {
        return Price;
    }

    public int GetAvailableQuantity()
    {
        return AvailableQuantity;
    }

    public void AddQuantity(int amount)
    {
        AvailableQuantity += amount;
    }

    public void SellQuantity(int amount)
    {
        if (AvailableQuantity >= amount)
        {
            AvailableQuantity -= amount;
            Console.WriteLine($"{amount} books sold. Remaining quantity: {AvailableQuantity}");
        }
        else
        {
            Console.WriteLine("Insufficient quantity available.");
        }
    }

    public virtual void ShowDetails()
    {
        Console.WriteLine($"ISBN: {Isbn}");
        Console.WriteLine($"Title: {BookTitle}");
        Console.WriteLine($"Author: {AuthorName}");
        Console.WriteLine($"Price: {Price}");
        Console.WriteLine($"Available Quantity: {AvailableQuantity}");
    }
}
