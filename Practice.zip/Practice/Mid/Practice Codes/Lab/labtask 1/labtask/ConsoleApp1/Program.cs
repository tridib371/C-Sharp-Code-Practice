﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Account account1 = new Account("Mehedi", "22-46566-1", 1000.00);

    
            Console.WriteLine("Initial Account Details:");
            account1.PrintAccountDetails();

           
            account1.Deposit(500.50);

           
            Console.WriteLine("\nAccount Details After Deposit:");
            account1.PrintAccountDetails();

         
            account1.Withdraw(200.25);

            
            Console.WriteLine("\nAccount Details After Withdrawal:");
            account1.PrintAccountDetails();

            Account account2 = new Account("John", "22-12345-6", 500.00);

            // Display initial account details for the second account
            Console.WriteLine("\nInitial Account Details for Account2:");
            account2.PrintAccountDetails();

            // Transfer funds from account1 to account2
            account1.Transfer(300.00, account2);

            // Display account details after transfer
            Console.WriteLine("\nAccount Details After Transfer:");
            //account1.PrintAccountDetails();
            account2.PrintAccountDetails();














            Console.ReadKey();

        }
    }
}
