﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Account
    {
        private string accName;
        private string acid;
        private double balance;



        public void SetAccName(string newAccName)
        {
            this.accName = newAccName;
        }


        public string GetAccName()
        {
            return accName;
        }



        public void SetAcid(string newAcid)
        {
            this.acid = newAcid;
        }
        public string GetAcid()
        {
            return acid;
        }


        public void SetBalance(double newBalance)
        {
            this.balance = newBalance;
        }
        public double GetBalance()
        {
            return balance;
        }
        public Account()
        {

        }
        public Account(string accName, string acid, double balance)
        {
            this.accName = accName;
            this.acid = acid;
            this.balance = balance;
        }
        public void Deposit(double amount)
        {
            if (amount > 0)
            {
                balance = balance + amount;
                Console.WriteLine($"Deposit of {amount:F2} successful. Updated balance: {balance:F2}");


            }
            else
            {
                Console.WriteLine("Invalid deposit amount. Please enter a positive value.");
            }
        }

        public void Withdraw(double amount)
        {
            if (amount > 0 && amount <= balance)
            {
                balance = balance - amount;
                 Console.WriteLine($"Withdrawal of {amount:F2} successful. Updated balance: {balance:F2}");
                //Console.WriteLine("Withdrawal of " + amount+ " successful. Updated balance: " + balance) ;


            }
            else if (amount <= 0)
            {
                Console.WriteLine("Invalid withdrawal amount. Please enter a positive value.");
            }
            else
            {
                Console.WriteLine("Insufficient funds. Withdrawal amount exceeds the current balance.");
            }
        }
        public void Transfer(double amount, Account receiver)
        {
            if (amount > 0 && amount <= balance)
            {
                Withdraw(amount);
                receiver.Deposit(amount);
                Console.WriteLine($"Transfer of {amount:F2} successful. Updated balance: {balance:F2}");

            }
            else if (amount <= 0)
            {
                Console.WriteLine("Invalid transfer amount. Please enter a positive value.");
            }
            else
            {
                Console.WriteLine("Insufficient funds. Transfer amount exceeds the current balance.");
            }
        }


        public void PrintAccountDetails()
        {
            Console.WriteLine($"Account Name: {GetAccName()}");
            Console.WriteLine($"Account ID: {GetAcid()}");
            Console.WriteLine($"Account Balance: {GetBalance():F2}");
        }










    }
}
