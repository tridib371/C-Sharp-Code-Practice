﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTask2
{
    class Date
    {
        private int dd;
        private int mm;
        private int yy;

        public Date(int dd = 1, int mm = 1, int yy = 2017)
        {
            setDate(dd, mm, yy);
        }

        public void setDate(int dd, int mm, int yy)
        {
            this.dd = dd;
            this.mm = mm;
            this.yy = yy;
        }

        public int getDD
        {
            get { return dd; }
        }

        public int getMM
        {
            get { return mm; }
        }

        public int getYY
        {
            get { return yy; }
        }
    }
}
