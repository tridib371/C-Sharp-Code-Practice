﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTask2
{
    class TestDriver
    {
        static void Main(string[] args)
        {
            // Declare 4 Appointment objects
            Appointment appt1 = new Appointment("S12345", "Ian Ah Sam", 45.00, new Date(2, 3, 2015), new Date(8, 6, 2015));
            Appointment appt2 = new Appointment("S34567", "Lee Tao San", 60.00, new Date(3, 3, 2015), new Date(0, 0, 0));
            Appointment appt3 = new Appointment("S56783", "Sam Ting", 120.50, new Date(10, 3, 2015), new Date(31, 3, 2015));
            Appointment appt4 = new Appointment("S98761", "Anthony Chin", 78.50, new Date(31, 3, 2015), new Date(30, 4, 2015));

            // Display all appointment objects using default displayAppt() method
            Console.WriteLine("All Appointments:");
            appt1.displayAppt();
            appt2.displayAppt();
            appt3.displayAppt();
            appt4.displayAppt();

            Console.WriteLine();

            // Display a single appointment object using displayAppt(string) method, passing in NRIC "S56783"
            Console.WriteLine("Print single appointment: $56783");
            string searchNRIC = "S56783 ";
            appt1.displayAppt(searchNRIC);
            appt2.displayAppt(searchNRIC);
            appt3.displayAppt(searchNRIC);
            appt4.displayAppt(searchNRIC);

            Console.ReadLine();
        }
    }
}
