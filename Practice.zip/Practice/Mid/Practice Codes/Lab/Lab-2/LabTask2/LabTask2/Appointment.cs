﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTask2
{
    class Appointment
    {
        private string NRIC;
        private string name;
        private double fees;
        private Date visit;
        private Date nextVisit;

        public Appointment(string NRIC, string name, double fees, Date visit, Date nextVisit)
        {
            setAppt(NRIC, name, fees, visit, nextVisit);
        }

        public void setAppt(string NRIC, string name, double fees, Date visit, Date nextVisit)
        {
            this.NRIC = NRIC;
            this.name = name;
            this.fees = fees;
            this.visit = visit;
            this.nextVisit = nextVisit;
        }

        public string getVisit
        {
            get { return visit.getDD + "/" + visit.getMM + "/" + visit.getYY; }
        }

        public string getnextVisit
        {
            get
            {
                if (nextVisit.getDD == 0)
                {
                    return "-";
                }
                else
                {
                    return nextVisit.getDD + "/" + nextVisit.getMM + "/" + nextVisit.getYY;
                }
            }
        }

        public string getName
        {
            get { return name; }
        }

        public void displayAppt()
        {
            Console.WriteLine($"{NRIC}, {name}, {fees}");
            Console.WriteLine($"{visit.getDD} {visit.getMM}{visit.getYY}");
            Console.WriteLine($"{getnextVisit}");
        }

        public void displayAppt(string nric)
        {
            if (NRIC == nric)
            {
                displayAppt();
            }
        }
        
    }
}
