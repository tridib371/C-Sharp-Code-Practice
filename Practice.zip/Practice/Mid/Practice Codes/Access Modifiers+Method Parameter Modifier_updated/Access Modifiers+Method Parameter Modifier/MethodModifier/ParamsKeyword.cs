﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodModifier
{
    class ParamsKeyword
    {
        
        public static void printarray(params object[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }
        }


        public static void Main(string[] args)
        {
            int[] myarray = { 5, 6, 7, 8, 9, 10 };

            printarray(myarray);

            Console.WriteLine("Hello ");

            printarray(5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 3434, 5656, 768787, 56556);


            Console.WriteLine("Hello {0} {1} {2} {3} {4} {5} {6} ", 5, 6, 7, 8, 9, 10, 11);//(params works by default)

            Console.ReadKey();
        }
    }
}
