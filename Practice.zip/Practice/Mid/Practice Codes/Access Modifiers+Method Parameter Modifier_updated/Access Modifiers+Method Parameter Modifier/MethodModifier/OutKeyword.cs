﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodModifier
{
    class OutKeyword
    {

        public static void Add(out int x)
        {
            x = 3;

        }



        public static void Main(string[] args)
        {

            int x;
            Add(out x );
            Console.WriteLine(x);


            Console.ReadKey();
        }

    }
}
