﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodModifier
{
    class Example
    {
        public static void receiverMethod(ref int val)
        {
            Console.WriteLine("Value is : " + val);
            val = 20;
            Console.WriteLine("Value is : " + val);

        }

        public static void Main(string[] args)
        {
            int age = 50;
            Console.WriteLine("at the beginning: " + age);

            receiverMethod(ref age);
            Console.WriteLine("after method calling: " + age);

            Console.ReadLine();
        }
    }
}

