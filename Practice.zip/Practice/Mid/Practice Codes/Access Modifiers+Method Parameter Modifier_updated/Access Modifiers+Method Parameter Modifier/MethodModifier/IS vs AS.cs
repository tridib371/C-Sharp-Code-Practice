﻿using System;

namespace MethodModifier
{
    class Is_vs_AS
    {
        static void Main(string[] args) // Note: "Main" should be capitalized
        {
            // IS x variable type of String
            object x = "dadaboudi";
            if (x is string) // Check if x is of type string
            {
                Console.WriteLine("Yes, they are the same type."); // If x is a string, print this
            }
            else
            {
                Console.WriteLine("No, they are not the same type."); // If x is not a string, print this
            }

            // Can we convert x string AS an object?
            string y = x as string; // Attempt to cast x as a string and assign it to y using the 'as' operator

            if (y != null) // Check if the casting was successful
            {
                Console.WriteLine("Conversion successful: x can be cast as a string."); // If successful, print this
            }
            else
            {
                Console.WriteLine("Conversion failed: x cannot be cast as a string."); // If failed, print this
            }

            Console.ReadKey();
        }

    }
}