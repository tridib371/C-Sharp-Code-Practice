﻿using System;

namespace TridibConsoleApp
{
    class Program
    {
        // Declare firstname and lastname as member variables
        string firstname, lastname;

        static void Main(string[] args)
        {
            // Uncomment these lines to declare and initialize firstname and lastname
            // string firstname = "tridib";
            // string lastname = "sarkar";

            // Create an instance of the Program class
            Program a = new Program();

            // Set the value of firstname and lastname using the instance
            a.firstname = "tridib";
            a.lastname = "sarkar";

            // Uncommented line, but firstname and lastname need to be member variables
            // Console.WriteLine("HELLO WORLD \n abcd " + a.firstname);

            // Corrected syntax for the Console.WriteLine line
            Console.WriteLine("The full name: {0} {1}", a.firstname, a.lastname);

            Console.ReadLine();
        }
    }
}
