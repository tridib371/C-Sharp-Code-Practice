﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;// namespace needed for optional parameter keyword

// Optional Parameters in C#

namespace Named_Optional_Parameter
{
    class OptionalParameterExample
    {
        public static int AddNumber(int firstNumber, int secondNumber = 0)
        {
            return firstNumber + secondNumber;
        }
        public static int AddNumber1(int firstNumber, [Optional] int secondNumber)
        {
            return firstNumber + secondNumber;
        }
        static void Main(string[] args)
        {
            AddNumber(12);
            AddNumber1(12);
        }
    }
}
