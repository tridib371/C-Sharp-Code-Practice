﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegateExample3
{
    delegate int MyFirstDelegate(int a, int b);
    class Program
    {
        //static int Calculate(int x, int y)
        //{
        //    Console.WriteLine(string.Format("x: {0}. y; {1}", x, y));
        //    return x + y;
        //}

        static void Main(string[] args)
        {
            MyFirstDelegate mfd = (int x, int y) =>
            {
                Console.WriteLine(string.Format("x: {0}. y; {1}", x, y));
                return x + y;
            };

            int result = mfd(1, 2);
            Console.ReadLine();
        }
    }
}
