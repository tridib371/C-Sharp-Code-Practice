﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HelloWindowsApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-E3Q2TV4\SQLEXPRESS;Initial Catalog=Demo;Integrated Security=True");
 

        private void button_Clear_Click(object sender, EventArgs e)
        {
            

            textBox_UN.Clear();
            textBox_PW.Clear();

            textBox_UN.Focus();
        }

        private void button_LogIn_Click(object sender, EventArgs e)
        {
            
            string query = "Select * from test where username='" + textBox_UN.Text + "' and password='" + textBox_PW.Text + "'";

            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();  //blank table

            sda.Fill(dt);

            if(dt.Rows.Count == 1)
            {
                Form2 f2 = new Form2();
                this.Hide();
                f2.Show();
            }
            else
            {
                MessageBox.Show("Wrong Credentials!!!\nTry again.");
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Do you really want to exit the application?", "Exit Window", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)==DialogResult.No)
            {
                Application.Exit();
            }
        }

        private void textBox_PW_KeyDown(object sender, KeyEventArgs e)
        {
            
            if(e.KeyCode == Keys.Enter)
            {
                if (textBox_UN.Text == "admin" && textBox_PW.Text == "admin")
                {
                    Form2 f2 = new Form2();
                    this.Hide();
                    f2.Show();
                }
                else
                {
                    MessageBox.Show("Wrong Credentials!!!\nTry again.");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            

            string query = "insert into test values ('"+textBox_UN.Text+"', '"+textBox_PW.Text+"')";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();

            if(con.State == ConnectionState.Open)
            {
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                    MessageBox.Show("Insertion is successfull");
            }
                    
        }

        private void button3_Click(object sender, EventArgs e)
        {

            string query = "update test set Password= "+textBox_PW.Text+" where Username='"+textBox_UN.Text+"'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();

            if (con.State == ConnectionState.Open)
            {
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                    MessageBox.Show("Update is successfull");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "delete from test where username='"+textBox_UN.Text+"' and password='"+textBox_PW.Text+"'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();

            if (con.State == ConnectionState.Open)
            {
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                    MessageBox.Show("Delete is successfull");
                else
                    MessageBox.Show("Delete is not successfull");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string query = "Select * from test";

            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();  //blank table

            sda.Fill(dt);

            dataGridView1.DataSource = dt;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string query = "Select * from test where username like '%" + textBox1.Text + "%'";

            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();  //blank table

            sda.Fill(dt);

            dataGridView1.DataSource = dt;
        }
    }
}
