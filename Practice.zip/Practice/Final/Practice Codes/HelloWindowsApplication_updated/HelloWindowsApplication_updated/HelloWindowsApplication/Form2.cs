﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace HelloWindowsApplication
{
    public partial class Form2 : Form
    {
        string username;
        public Form2()
        {
            InitializeComponent();
        }

        public Form2(string un)
        {
            this.username = un;
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox_item.Text);
            comboBox1.Items.Add(textBox_item.Text);
            textBox_item.Clear();
            textBox_item.Focus();

          
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://www.google.com");
        }
    }
}
