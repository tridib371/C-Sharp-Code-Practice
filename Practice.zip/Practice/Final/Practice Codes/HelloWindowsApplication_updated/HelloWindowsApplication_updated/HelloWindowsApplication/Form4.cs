﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloWindowsApplication
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button_LogIn_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(textBox_id.Text) || string.IsNullOrEmpty(textBox_name.Text))  
                    return;

            ListViewItem item = new ListViewItem(textBox_id.Text);
            item.SubItems.Add(textBox_name.Text);

            listView1.Items.Add(item);
        }
    }
}
