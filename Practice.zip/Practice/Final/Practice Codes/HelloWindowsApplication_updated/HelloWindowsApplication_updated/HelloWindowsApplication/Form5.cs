﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloWindowsApplication
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        int seconds = 10;
        private void button1_Click(object sender, EventArgs e)
        {
            counter.Start();
            
        }

        private void counter_Tick(object sender, EventArgs e)
        {
            labelTime.Text = seconds--.ToString();

            if (seconds < 0)
            {
                counter.Stop();
                MessageBox.Show("time's up!!"); 
            }
                
        }
    }
}
