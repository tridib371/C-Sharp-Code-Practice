﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialClass
{
    public interface Iinterface1
    {
        void show();
    }
    public partial class PartialCustomer : Iinterface1
    {
        public void GetFullName()
        {
            Console.WriteLine(firstName + ", " + lastName);
        }

        public void show2()
        {
        }
        public void show()
        {
        }
    }

    public class Sample2
    {
    }
}
