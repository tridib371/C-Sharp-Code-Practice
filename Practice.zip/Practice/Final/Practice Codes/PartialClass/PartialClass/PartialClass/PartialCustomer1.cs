﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialClass
{
    public interface Iinterface2
    {
        void show2();
    }
    partial class PartialCustomer : Iinterface2
    {
        string firstName, lastName;

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        
    }

    public class Sample 
    {
    }
}
