﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer c = new Customer();
            c.FirstName = "Zahiduddin";
            c.LastName = "Ahmed";
            c.GetFullName();

            PartialCustomer p = new PartialCustomer();
            p.FirstName = "Zahiduddin";
            p.LastName = "Ahmed";

            p.GetFullName();

            SampleParitalMethod sp = new SampleParitalMethod();
            sp.PublicMethod();
            Console.ReadKey();
        }
    }
}
