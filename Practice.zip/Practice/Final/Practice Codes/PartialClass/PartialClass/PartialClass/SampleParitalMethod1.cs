﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialClass
{
    partial class SampleParitalMethod
    {
        partial void SimpleMethod()
        {
            Console.WriteLine("SimpleMethod is invoked!!");
        }
    }
}
