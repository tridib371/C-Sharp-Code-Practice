﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialClass
{
    partial class SampleParitalMethod
    {
        partial void SimpleMethod(); // declaration, not implementation

        public void PublicMethod()
        {
            Console.WriteLine("Public Method is Invoked!");
            SimpleMethod();
        }
    }
}
