﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloWindowsApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

 

        private void button_Clear_Click(object sender, EventArgs e)
        {
            

            textBox_UN.Clear();
            textBox_PW.Clear();

            textBox_UN.Focus();
        }

        private void button_LogIn_Click(object sender, EventArgs e)
        {
            
            if (textBox_UN.Text=="admin" && textBox_PW.Text=="admin")
            {
                Form2 f2 = new Form2(textBox_UN.Text);
                this.Hide();
                f2.Show();
            }
            else
            {
                MessageBox.Show("Wrong Credentials!!!\nTry again.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Do you really want to exit the application?", "Exit Window", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)==DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void textBox_PW_KeyDown(object sender, KeyEventArgs e)
        {
            
            if(e.KeyCode == Keys.Enter)
            {
                if (textBox_UN.Text == "admin" && textBox_PW.Text == "admin")
                {
                    Form2 f2 = new Form2();
                    this.Hide();
                    f2.Show();
                }
                else
                {
                    MessageBox.Show("Wrong Credentials!!!\nTry again.");
                }
            }
        }
    }
}
