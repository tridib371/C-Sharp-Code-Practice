﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac
{
    public partial class Form1 : Form
    {
        int turn = 1;
        int click1 = 0, click2 = 0, click3 = 0, click4 = 0, click9 = 0, click5 = 0, click6 = 0,click7=0,click8=0;
        int player1 = 0;
        int player2 = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int click1 = 0;
            if (click1 == 0)
            {
                if (turn % 2 != 0)
                {
                    button1.Text = "X";
                }
                else
                {
                    button1.Text = "O";
                }
                turn++;
                click1++;
            }
            else
            {
                button1.Text = button1.Text;
            }
            display();
            result();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int click2 = 0;
            if (click2 == 0)
            {
                if (turn % 2 != 0)
                {
                    button2.Text = "X";
                }
                else
                {
                    button2.Text = "O";
                }
                turn++;
                click2++;
            }
            else
            {
                button2.Text = button2.Text;
            }
            display();
            result();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int click3 = 0;
            if (click3 == 0)
            {
                if (turn % 2 != 0)
                {
                    button3.Text = "X";
                }
                else
                {
                    button3.Text = "O";
                }
                turn++;
                click3++;
            }
            else
            {
                button3.Text = button3.Text;
            }
            display();
            result();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int click4 = 0;
            if (click4 == 0)
            {
                if (turn % 2 != 0)
                {
                    button4.Text = "X";
                }
                else
                {
                    button4.Text = "O";
                }
                turn++;
                click4++;
            }
            else
            {
                button4.Text = button4.Text;
            }
            display();
            result();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int click5 = 0;
            if (click5 == 0)
            {
                if (turn % 2 != 0)
                {
                    button5.Text = "X";
                }
                else
                {
                    button5.Text = "O";
                }
                turn++;
                click5++;
                
            }
            else
            {
                button5.Text = button5.Text;
            }
            display();
            result();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int click6 = 0;
            if (click6 == 0)
            {
                if (turn % 2 != 0)
                {
                    button6.Text = "X";
                }
                else
                {
                    button6.Text = "O";
                }
                turn++;
                click6++;
            }
            else
            {
                button6.Text = button6.Text;
            }
            display();
            result();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int click7 = 0;
            if (click7 == 0)
            {
                if (turn % 2 != 0)
                {
                    button7.Text = "X";
                }
                else
                {
                    button7.Text = "O";
                }
                turn++;
                click7++;
            }
            else
            {
                button7.Text = button7.Text;
            }
            display();
            result();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int click8 = 0;
            if (click8 == 0)
            {
                if (turn % 2 != 0)
                {
                    button8.Text = "X";
                }
                else
                {
                    button8.Text = "O";
                }
                turn++;
                click8++;
            }
            else
            {
                button8.Text = button8.Text;
            }
            display();
            result();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int click9 = 0;
            if (click9 == 0)
            {
                if (turn % 2 != 0)
                {
                    button9.Text = "X";
                }
                else
                {
                    button9.Text = "O";
                }
                turn++;
                click9++;
            }
            else
            {
                button9.Text = button9.Text;
            }
            display();
            result();
        }

        public void display()
        {
            if (turn % 2 != 0)
            {
                turnBox.Text = "Player 1 [X]";
            }
            else
            {
                turnBox.Text = "Player 2 [O]";
            }
        }

        public void result()
        {
            if (button1.Text != "" && button2.Text != "" && button3.Text != "")
            {
                if (button1.Text == button2.Text && button1.Text == button3.Text)
                {
                    button1.BackColor = Color.Green;
                    button1.ForeColor = Color.White;
                    button2.BackColor = Color.Green;
                    button2.ForeColor = Color.White;
                    button3.BackColor = Color.Green;
                    button3.ForeColor = Color.White;
                    if (button1.Text == "X")
                    {
                        MessageBox.Show("Player 1 Wins!");
                        player1++;
                        pl1.Text = player1.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Player 2 Wins!");
                        player2++;
                        pl2.Text = player2.ToString();
                    }
                    newGame();    
                }
            }

            if (button4.Text != "" && button5.Text != "" && button6.Text != "")
            {
                if (button4.Text == button5.Text && button4.Text == button6.Text)
                {
                    button4.BackColor = Color.Green;
                    button4.ForeColor = Color.White;
                    button5.BackColor = Color.Green;
                    button5.ForeColor = Color.White;
                    button6.BackColor = Color.Green;
                    button6.ForeColor = Color.White;
                    if (button4.Text == "X")
                    {
                        MessageBox.Show("Player 1 Wins!");
                        player1++;
                        pl1.Text = player1.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Player 2 Wins!");
                        player2++;
                        pl2.Text = player2.ToString();
                    }
                    newGame();
                }
            }

            if (button7.Text != "" && button8.Text != "" && button9.Text != "")
            {
                if (button7.Text == button8.Text && button7.Text == button9.Text)
                {
                    button7.BackColor = Color.Green;
                    button7.ForeColor = Color.White;
                    button8.BackColor = Color.Green;
                    button8.ForeColor = Color.White;
                    button9.BackColor = Color.Green;
                    button9.ForeColor = Color.White;
                    if (button7.Text == "X")
                    {
                        MessageBox.Show("Player 1 Wins!");
                        player1++;
                        pl1.Text = player1.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Player 2 Wins!");
                        player2++;
                        pl2.Text = player2.ToString();
                    }
                    newGame();
                }
            }

            if (button1.Text != "" && button4.Text != "" && button7.Text != "")
            {
                if (button1.Text == button4.Text && button1.Text == button7.Text)
                {
                    button1.BackColor = Color.Green;
                    button1.ForeColor = Color.White;
                    button4.BackColor = Color.Green;
                    button4.ForeColor = Color.White;
                    button7.BackColor = Color.Green;
                    button7.ForeColor = Color.White;
                    if (button1.Text == "X")
                    {
                        MessageBox.Show("Player 1 Wins!");
                        player1++;
                        pl1.Text = player1.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Player 2 Wins!");
                        player2++;
                        pl2.Text = player2.ToString();
                    }
                    newGame();
                }
            }

            if (button2.Text != "" && button5.Text != "" && button8.Text != "")
            {
                if (button2.Text == button5.Text && button2.Text == button8.Text)
                {
                    button2.BackColor = Color.Green;
                    button2.ForeColor = Color.White;
                    button5.BackColor = Color.Green;
                    button5.ForeColor = Color.White;
                    button8.BackColor = Color.Green;
                    button8.ForeColor = Color.White;
                    if (button2.Text == "X")
                    {
                        MessageBox.Show("Player 1 Wins!");
                        player1++;
                        pl1.Text = player1.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Player 2 Wins!");
                        player2++;
                        pl2.Text = player2.ToString();
                    }
                    newGame();
                }
            }

            if (button3.Text != "" && button6.Text != "" && button9.Text != "")
            {
                if (button3.Text == button6.Text && button3.Text == button9.Text)
                {
                    button3.BackColor = Color.Green;
                    button3.ForeColor = Color.White;
                    button6.BackColor = Color.Green;
                    button6.ForeColor = Color.White;
                    button9.BackColor = Color.Green;
                    button9.ForeColor = Color.White;
                    if (button3.Text == "X")
                    {
                        MessageBox.Show("Player 1 Wins!");
                        player1++;
                        pl1.Text = player1.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Player 2 Wins!");
                        player2++;
                        pl2.Text = player2.ToString();
                    }
                    newGame();
                }
            }

            if (button1.Text != "" && button5.Text != "" && button9.Text != "")
            {
                if (button1.Text == button5.Text && button1.Text == button9.Text)
                {
                    button1.BackColor = Color.Green;
                    button1.ForeColor = Color.White;
                    button5.BackColor = Color.Green;
                    button5.ForeColor = Color.White;
                    button9.BackColor = Color.Green;
                    button9.ForeColor = Color.White;
                    if (button1.Text == "X")
                    {
                        MessageBox.Show("Player 1 Wins!");
                        player1++;
                        pl1.Text = player1.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Player 2 Wins!");
                        player2++;
                        pl2.Text = player2.ToString();
                    }
                    newGame();
                }
            }

            if (button3.Text != "" && button5.Text != "" && button7.Text != "")
            {
                if (button3.Text == button5.Text && button3.Text == button7.Text)
                {
                    button3.BackColor = Color.Green;
                    button3.ForeColor = Color.White;
                    button5.BackColor = Color.Green;
                    button5.ForeColor = Color.White;
                    button7.BackColor = Color.Green;
                    button7.ForeColor = Color.White;
                    if (button3.Text == "X")
                    {
                        MessageBox.Show("Player 1 Wins!");
                        player1++;
                        pl1.Text = player1.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Player 2 Wins!");
                        player2++;
                        pl2.Text = player2.ToString();
                    }
                    newGame();
                }
            }

        }

        public void newGame()
        {
            turnBox.Text = "";
            button1.Text = "";
            button1.BackColor = Color.Empty;
            button1.ForeColor = Color.Black;
            button2.Text = "";
            button2.BackColor = Color.Empty;
            button2.ForeColor = Color.Black;
            button3.Text = "";
            button3.BackColor = Color.Empty;
            button3.ForeColor = Color.Black;
            button4.Text = "";
            button4.BackColor = Color.Empty;
            button4.ForeColor = Color.Black;
            button5.Text = "";
            button5.BackColor = Color.Empty;
            button5.ForeColor = Color.Black;
            button6.Text = "";
            button6.BackColor = Color.Empty;
            button6.ForeColor = Color.Black;
            button7.Text = "";
            button7.BackColor = Color.Empty;
            button7.ForeColor = Color.Black;
            button8.Text = "";
            button8.BackColor = Color.Empty;
            button8.ForeColor = Color.Black;
            button9.Text = "";
            button9.BackColor = Color.Empty;
            button9.ForeColor = Color.Black;
            click1 = 0;
            click2 = 0;
            click3 = 0;
            click4 = 0;
            click9 = 0;
            click5 = 0;
            click6 = 0;
            click7 = 0;
            click8 = 0;


        }
        private void playAgainbutton_Click(object sender, EventArgs e)
        {
            newGame();            
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        
    }
}
