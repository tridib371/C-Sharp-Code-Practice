﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DynamicTableLayout
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnChangeGridSize_Click(object sender, EventArgs e)
        {
            SuspendLayout(); 
            tableLayoutPanel1.SuspendLayout();
            editableTableLayoutPanel.SuspendLayout();





            editableTableLayoutPanel.RowStyles.Clear();
            editableTableLayoutPanel.ColumnStyles.Clear();
            editableTableLayoutPanel.Controls.Clear();

            editableTableLayoutPanel.RowCount = editableTableLayoutPanel.ColumnCount = (int)udGridSize.Value;

            for (int i = 0; i < (int)udGridSize.Value; i++)
            {
                editableTableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100 / (int)udGridSize.Value));
                editableTableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100 / (int)udGridSize.Value));
            }

            for (int i = 0; i < (int)udGridSize.Value; i++)
            {
                for (int j = 0; j < (int)udGridSize.Value; j++)
                {
                    Label iconLabel = new Label();
                    //iconLabel.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
                    iconLabel.Dock = DockStyle.Fill;
                    iconLabel.TextAlign = ContentAlignment.MiddleCenter;
                    iconLabel.Text = i + "," + j;

                    editableTableLayoutPanel.Controls.Add(iconLabel, i, j);
                }
            }

            editableTableLayoutPanel.ResumeLayout(true);
            tableLayoutPanel1.ResumeLayout(true);
            ResumeLayout(true);
        }
    }
}
