﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestInterface
{
    interface ITestInterface1
    {
        void Add(int a, int b);        
    }
    interface ITestInterface2 : ITestInterface1
    {        
        void Sub(int a, int b);
    }

    class TestInterface : ITestInterface2
    {
        public void Add(int a, int b)
        {
            Console.WriteLine("Declared in Interface1 and implemented in the class\n Sum is: " + (a + b));
        }

        public void Sub(int a, int b)
        {
            Console.WriteLine("Declared in Interface2 and implemented in the class\n Sub is: " + (a - b));
        }

        static void Main(string[] args)
        {
            TestInterface TI = new TestInterface();
            TI.Add(10, 20);
            TI.Sub(10, 20);

            Console.ReadKey();
        }
    }
}
