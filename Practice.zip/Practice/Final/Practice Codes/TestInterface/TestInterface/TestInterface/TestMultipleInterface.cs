﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestInterface
{
    interface interface1
    {
        //int x;
        void Test();
        void Show();       
    }

    interface interface2
    {
        void Test();
        void Show();        
    }
    class TestMultipleInterface:interface1,interface2
    {
        void interface1.Show() // Explicit Interface Implementation
        {
            Console.WriteLine("Declared in interface1 and Explicitly implemented in the class");
        }
        void interface2.Show() // Explicit Interface Implementation
        {
            Console.WriteLine("Declared in interface2 and Explicitly implemented in the class");
        }
        public void Test() // Implicit Interface Implementation
        {
            Console.WriteLine("Declared in interface1 and interface2, but implemented once in the class");
        }
        static void Main(string[] args)
        {
            TestMultipleInterface t = new TestMultipleInterface();
            t.Test(); // Implicit Method Calling

            interface1 i1 = t;
            i1.Show(); // Explicit Method Calling

            ((interface2)t).Show();  // Explicit Method Calling
            


            Console.ReadKey();
        }

    }
}
