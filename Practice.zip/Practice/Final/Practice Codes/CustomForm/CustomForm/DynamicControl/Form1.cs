﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DynamicControl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        //    int start_position = 100;
        //    int end_position = 10;

            //for (int i = 0; i < numericUpDown1.Value; i++)
            //{
            //    Button b = addButton(i);
            //    //end_position += 100;
            //    //this.Controls.Add(b);
            //    flowLayoutPanel1.Controls.Add(b);
            //    b.Click += new EventHandler(this.b_Click);
            //}
        }

        void b_Click(object sender, EventArgs e)
        {
            MessageBox.Show((sender as Button).Text);
        }
        Button addButton(int i)
        {
            Button b = new Button();
            b.Name = "button" + (i+1).ToString();
            b.Text = "button" + (i+1).ToString();
            b.ForeColor = Color.White;
            b.BackColor = Color.Green;
            b.Size = new Size(160, 80);
            //b.Location = new Point(start, end);
            b.Font = new Font("serif",24, FontStyle.Bold);
            return b;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();
            for (int i = 0; i < numericUpDown1.Value; i++)
            {
                Button b = addButton(i);
                //end_position += 100;
                //this.Controls.Add(b);
                flowLayoutPanel1.Controls.Add(b);
                b.Click += new EventHandler(this.b_Click);
            }
        }
    }
}
