﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomizedForm
{
    public partial class Content : UserControl
    {
        public int index;
        public Content()
        {            
            InitializeComponent();
        }

        public delegate void RemoveEventHandler(Object sender);
        public event RemoveEventHandler OnRemove;

        private void button_remove_Click(object sender, EventArgs e)
        {
            OnRemove(this);
        }
    }
}
