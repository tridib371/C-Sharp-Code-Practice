﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomizedForm
{
    public partial class Form1 : Form
    {
        const int space = 3;

        public Form1()
        {
            InitializeComponent();
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            Content content = new Content();
            Content previous;
            panel_main.Controls.Add(content);

            if (panel_main.Controls.Count == 1)
                content.Location = new Point(0, 0);
            else
            {
                previous = (Content) panel_main.Controls[panel_main.Controls.Count-2];
                content.Location = new Point(0,previous.Location.Y+previous.Height+space);
            }
            content.index = panel_main.Controls.Count -1;
            content.OnRemove += new Content.RemoveEventHandler(this.RemoveMethod);
            content.Width = panel_main.Width;
            content.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right | System.Windows.Forms.AnchorStyles.Left)));                
        }

        void RemoveMethod(object sender)
        {
            int deleteIndex = (sender as Content).index;
           
            Content updateList;

            for (int i = deleteIndex+1; i < panel_main.Controls.Count; i++)
            {
                updateList = (Content)panel_main.Controls[i];
                updateList.Location = new Point(0, updateList.Location.Y - updateList.Height - space);
                updateList.index = i - 1;
            }
            
            panel_main.Controls.RemoveAt(deleteIndex);
        }
    }
}
