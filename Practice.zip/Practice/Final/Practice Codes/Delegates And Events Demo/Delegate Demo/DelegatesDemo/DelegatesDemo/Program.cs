﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    public delegate void Transform(int i);
    class Program
    {
        static void Main(string[] args)
        {
            Transform t = Square;
            t += new Transform(Cube);
            t(5);
            t -= Cube;
            t(6);
            
            t += new ForeignClass().ForeignMethod;
            t(7);
        }

        static void Square(int i)
        {
            Console.WriteLine(i * i);
        }
        static void Cube(int i)
        {
            Console.WriteLine(i * i * i);
        }
    }
}
