﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsDemo
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Stock s = new Stock("ABBANK");            
            s.Price = 27.1M;
            s.PriceChanged += s_PriceChanged;
            s.Price = 37.5M;
        }

        static void s_PriceChanged(decimal oldPrice, decimal newPrice)
        {
            Console.WriteLine("old Price:" + oldPrice + ", new price:" + newPrice);
        }
        
    }
}
