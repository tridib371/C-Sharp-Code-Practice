﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsDemo
{
    public delegate void PriceChangeHandler(decimal oldPrice, decimal newPrice);
    class Stock
    {
        string symbol;
        decimal price;
        public Stock(string s)
        {
            symbol = s;
        }
        public event PriceChangeHandler PriceChanged;
        public decimal Price
        {
            get
            {
                return price;
            }
            set
            {
                if (price == value)
                    return;

                decimal oldPrice = price;
                price = value;

                if (PriceChanged != null)
                {                    
                    PriceChanged(oldPrice, price);
                }
            }

        }


    }
}
