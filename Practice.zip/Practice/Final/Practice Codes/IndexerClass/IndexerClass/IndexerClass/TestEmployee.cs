﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerClass
{
    class TestEmployee
    {        
        static void Main(string[] args)
        {
            Employee emp = new Employee(101, 3, 10000, "Zahid", "Lecturer", "OurBelovedKuratoli");

            Console.WriteLine("Employee ID: " + emp[0]);
            Console.WriteLine("Employee Experience: " + emp[1]);
            Console.WriteLine("Employee Salary: " + emp[2]);
            Console.WriteLine("Employee Name: " + emp[3]);
            Console.WriteLine("Employee Designation: " + emp[4]);
            Console.WriteLine("Employee Office Location: " + emp[5]);

            emp["Name"] = "Ahmed";

            //List<double> values = new List<double>();
            
            Console.WriteLine("\nEmployee ID: " + emp["Id"]);
            Console.WriteLine("Employee Experience: " + emp["Experience"]);
            Console.WriteLine("Employee Salary: " + emp["Salary"]);
            Console.WriteLine("Employee Name: " + emp["Name"]);
            Console.WriteLine("Employee Designation: " + emp["Designation"]);
            Console.WriteLine("Employee Office Location: " + emp["Office_Location"]);

            Console.ReadKey();
        }
    }
}
